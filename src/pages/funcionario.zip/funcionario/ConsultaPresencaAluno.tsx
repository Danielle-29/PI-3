import React, { useState } from "react";
import {
  Box,
  Typography,
  TextField,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper
} from "@mui/material";
import { db } from "../../firebaseConfig";
import { collection, getDocs } from "firebase/firestore";
import "./PlanejamentoFuncionario.css"; // mantendo estilo padrao da pasta

const ConsultaPresencaFuncionario: React.FC = () => {
  const [curso, setCurso] = useState("");
  const [turma, setTurma] = useState("");
  const [nomeBusca, setNomeBusca] = useState("");
  const [resultados, setResultados] = useState<{ data: string; presente: boolean }[]>([]);

  const buscarPresenca = async () => {
    if (!curso || !turma || !nomeBusca) return;
    const presencaRef = collection(db, "cursos", curso, "turmas", turma, "presencas");
    const snapshot = await getDocs(presencaRef);

    const lista: { data: string; presente: boolean }[] = [];

    for (const docSnap of snapshot.docs) {
      const data = docSnap.id;
      const dados = docSnap.data();

      const alunoEncontrado = dados.alunos.find((a: any) => {
        const nome = (a.nome || a.nomeCompleto || "").toLowerCase();
        return nome.includes(nomeBusca.toLowerCase());
      });

      if (alunoEncontrado) {
        lista.push({ data, presente: alunoEncontrado.presente });
      }
    }

    setResultados(lista);
  };

  return (
    <div className="page-container">
      <div className="container-list">
        <Typography variant="h5" align="center" fontWeight="bold" sx={{ color: "#1B4BD2", mb: 3 }}>
          Consulta de Presença por Aluno
        </Typography>

        <Box display="flex" gap={2} mb={3} flexWrap="wrap" justifyContent="center">
          <FormControl sx={{ minWidth: 150 }} size="small">
            <InputLabel>Curso</InputLabel>
            <Select value={curso} onChange={(e) => setCurso(e.target.value)} label="Curso">
              <MenuItem value="ingles">Inglês</MenuItem>
              <MenuItem value="espanhol">Espanhol</MenuItem>
            </Select>
          </FormControl>

          <TextField
            label="Turma"
            value={turma}
            onChange={(e) => setTurma(e.target.value)}
            size="small"
          />

          <TextField
            label="Nome do aluno"
            value={nomeBusca}
            onChange={(e) => setNomeBusca(e.target.value)}
            size="small"
          />

          <Button variant="contained" onClick={buscarPresenca}>
            Buscar
          </Button>
        </Box>

        {resultados.length > 0 && (
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                  <TableCell><strong>Data</strong></TableCell>
                  <TableCell><strong>Presença</strong></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {resultados.map((item, index) => (
                  <TableRow key={index}>
                    <TableCell>{item.data}</TableCell>
                    <TableCell>{item.presente ? "✅ Presente" : "❌ Ausente"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </div>
    </div>
  );
};

export default ConsultaPresencaFuncionario;
