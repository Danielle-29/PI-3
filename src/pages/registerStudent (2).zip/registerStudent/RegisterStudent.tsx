import { db } from "../../firebaseConfig";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { FormData, schema } from "../../utils/FormInterfaces";
import { useNavigate } from "react-router-dom";
import { cadastrarAluno } from "../../utils/firestoreService";
import { collection, getDocs } from "firebase/firestore";

import "./registerStudent.css";

const RegisterStudent: React.FC = () => {
  const navigate = useNavigate();
  const [cursoMatriculado, setCursoMatriculado] = useState("");
  const [turma, setTurma] = useState("");
  const [turmasDisponiveis, setTurmasDisponiveis] = useState<string[]>([]);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>({
    resolver: yupResolver(schema),
  });

  useEffect(() => {
    const carregarTurmas = async () => {
      if (!cursoMatriculado) return;
      const snapshot = await getDocs(collection(db, "cursos", cursoMatriculado, "turmas"));
      const turmas = snapshot.docs.map(doc => doc.id);
      setTurmasDisponiveis(turmas);
    };
    carregarTurmas();
  }, [cursoMatriculado]);

  
  const onSubmit = async (data: FormData) => {
    try {
      const { cursoMatriculado: _, ...alunoSemCurso } = data; // Remove o campo cursoMatriculado do objeto
      await cadastrarAluno(cursoMatriculado, turma, alunoSemCurso);
      navigate("/form-enviado");
      console.log("Aluno cadastrado com sucesso!", alunoSemCurso);
    } catch (error) {
      console.error("Erro ao cadastrar aluno:", error);
    }
  };

  return (
    <div className="container-register">
      <h1>Formulário de Matrícula</h1>
      <form onSubmit={handleSubmit(onSubmit)}>
        <label>Selecione o curso desejado*</label>
        <select value={cursoMatriculado} onChange={(e) => setCursoMatriculado(e.target.value)} required>
          <option value="">Selecione</option>
          <option value="ingles">Inglês</option>
          <option value="espanhol">Espanhol</option>
        </select>

        <label>Turma*</label>
        <select value={turma} onChange={(e) => setTurma(e.target.value)} required>
          <option value="">Selecione</option>
          {turmasDisponiveis.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>

        {cursoMatriculado && turma && (
          <>
            <label>Nome Completo*</label>
            <input {...register("nome")} />
            {errors.nome && <p className="errors">{errors.nome.message}</p>}

            <label>Data de Nascimento*</label>
            <input {...register("dataNascimento")} />
            {errors.dataNascimento && <p className="errors">{errors.dataNascimento.message}</p>}

            <label>Idade*</label>
            <input {...register("idade")} />
            {errors.idade && <p className="errors">{errors.idade.message}</p>}

            <label>Estado Civil*</label>
            <input {...register("estadoCivil")} />
            {errors.estadoCivil && <p className="errors">{errors.estadoCivil.message}</p>}

            <label>Gênero*</label>
            <input {...register("genero")} />
            {errors.genero && <p className="errors">{errors.genero.message}</p>}

            <label>Nome da Mãe*</label>
            <input {...register("nomeMae")} />
            {errors.nomeMae && <p className="errors">{errors.nomeMae.message}</p>}

            <label>Nome do Pai</label>
            <input {...register("nomePai")} />

            <label>Nacionalidade*</label>
            <input {...register("nacionalidade")} />
            {errors.nacionalidade && <p className="errors">{errors.nacionalidade.message}</p>}

            <label>Naturalidade*</label>
            <input {...register("naturalidade")} />
            {errors.naturalidade && <p className="errors">{errors.naturalidade.message}</p>}

            <label>Cor/Etnia*</label>
            <input {...register("corEtnia")} />
            {errors.corEtnia && <p className="errors">{errors.corEtnia.message}</p>}

            <label>Situação Ocupacional</label>
            <input {...register("situacaoOcupacional")} />

            <label>Saúde</label>
            <textarea {...register("saude")} />

            <label>Rua*</label>
            <input {...register("endereco.rua")} />
            <label>Complemento</label>
            <input {...register("endereco.complemento")} />
            <label>Bairro*</label>
            <input {...register("endereco.bairro")} />
            <label>Cidade*</label>
            <input {...register("endereco.cidade")} />
            <label>UF*</label>
            <input {...register("endereco.uf")} />
            <label>CEP*</label>
            <input {...register("endereco.cep")} />
            <label>Telefone*</label>
            <input {...register("endereco.telefone1")} />
            <label>Email*</label>
            <input {...register("endereco.email")} />
            <label>Documento</label>
            <input {...register("endereco.documento")} />

            <label>Responsável</label>
            <input placeholder="Nome" {...register("responsavel.nome")} />
            <input placeholder="CPF" {...register("responsavel.cpf")} />
            <input placeholder="RG" {...register("responsavel.rg")} />
            <input placeholder="Telefone para Contato" {...register("responsavel.telefoneContato")} />

            <label>Matrícula</label>
            <input {...register("matricula")} />

            <button type="submit" className="form-login-btn inscricao">
              Cadastrar
            </button>
          </>
        )}
      </form>
    </div>
  );
};

export default RegisterStudent;