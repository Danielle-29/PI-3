import { db } from '../firebaseConfig';  
import { collection, addDoc } from 'firebase/firestore';

export const cadastrarAluno = async (
  curso: string, 
  turma: string,
  alunoData: any
) => {
  try {
    const turmaCollection = collection(db, "cursos", curso, "turmas", turma, "alunos");
    await addDoc(turmaCollection, alunoData);
    console.log(`Aluno cadastrado com sucesso no curso ${curso}, turma ${turma}!`);
  } catch (error) {
    console.error(`Erro ao cadastrar aluno no curso ${curso}, turma ${turma}: `, error);
    throw error;
  }
};
