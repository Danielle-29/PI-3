import { initializeApp, cert } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';

import * as turma1 from './turmas/ingles/turma1.json';
import * as turma2 from './turmas/ingles/turma2.json';
import * as turma3 from './turmas/ingles/turma3.json';
import * as turma4 from './turmas/ingles/turma4.json';
import * as espanhol1 from './turmas/espanhol/turma1.json';


import * as serviceAccount from '../serviceAccountKey.json';

initializeApp({
  credential: cert(serviceAccount as any),
});

const db = getFirestore();

async function importarAlunos(curso: string, turma: string, alunos: any[]) {
  console.log(`Importando ${alunos.length} alunos para ${curso} - ${turma}...`);

  const turmaRef = db.collection("cursos").doc(curso).collection(turma);

  for (const aluno of alunos) {
    await turmaRef.add(aluno);
  }

  console.log(`✅ ${alunos.length} alunos importados para ${curso} / ${turma}`);
}

async function main() {
  // Inglês
  await importarAlunos("ingles", "turma1", turma1);
  await importarAlunos("ingles", "turma2", turma2);
  await importarAlunos("ingles", "turma3", turma3);
  await importarAlunos("ingles", "turma4", turma4);

  // Espanhol
  await importarAlunos("espanhol", "turma1", espanhol1);

  process.exit(0);
}

main().catch((error) => {
  console.error("❌ Erro ao importar alunos:", error);
  process.exit(1);
});
